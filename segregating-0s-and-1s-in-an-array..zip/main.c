/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void segregate0and1(int arr[],int size)
{
    int right=size-1,left=0;
    while(left<right)
    {
        while(arr[left]==0 && left<right)
        left++;
        while(arr[right]==1 && left<right)
        right--;
        if(left<right)
        {
            arr[left]=0;
            arr[right]=1;
            left++;
            right--;
        }
    }
}
int main()
{
    int arr[]={0,1,0,1,0,1};
    int arr_size=6,i=0;
    segregate0and1(arr,arr_size);
    printf("segregated array is ");
    for(i=0;i<6;i++)
    printf("%d ",arr[i]);
    getchar();
    return 0;
}